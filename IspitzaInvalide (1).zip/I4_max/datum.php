<?php

class Datum
{
    public function trenutni()
    {
        $time = date("d.m.Y");

        return $time;
    }
}


?>