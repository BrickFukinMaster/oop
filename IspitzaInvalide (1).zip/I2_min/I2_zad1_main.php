<?php
//ty maja
include("I2_zad1_child.php");

$proizvod1 = new Proizvodi();

$proizvod1->Unos();
$proizvod1->Ispis();


?>