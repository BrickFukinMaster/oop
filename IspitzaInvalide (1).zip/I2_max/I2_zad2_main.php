<?php
//ty maja
include("I2_zad2_child.php");

$Polaznik = new Polaznici();
$Polaznik->Unos();
$Polaznik->Ispis();


?>