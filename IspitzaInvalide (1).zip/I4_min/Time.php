<?php

class Time
{
    public function show()
    {
        $time = date("h:i:s A");

        return $time;
    }

}

?>